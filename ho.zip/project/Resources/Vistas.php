<?php
require_once '/home/onclik/www/husaam/project/Resources/inline.php';
/* It's a variable that contains a string. */
$auth = "
----------Gateways Auth [✅]---------
-------------------------------------------------
[𖠧]Gateway Zoro
[Stripe Auth]
↳𝙵𝚘𝚛𝚖𝚊𝚝𝚘:/zr ᴄᴄ|ᴍᴍ|ʏʏ|ᴄᴠᴠ
Status: [$zrstatus $zrtick]
Comment: $zrcomment

";


/* It's a variable that contains a string. */
$mass = "----------Gateways Mass [$]---------
-------------------------------------------------
[𖠧]Gateway PitoXd ($) 
[Stripe]
↳𝙵𝚘𝚛𝚖𝚊𝚝𝚘:/mass ᴄᴄ|ᴍᴍ|ʏʏ|ᴄᴠᴠ
Status: [$massstatus $masstick]
Comment: $masscomment";



/* It's a variable that contains a string. */
$charge = "
----------Gateways Charged [$]---------
-------------------------------------------------
[𖠧]Gateway Rayko ($) 
[Paypal]
↳𝙵𝚘𝚛𝚖𝚊𝚝𝚘:/pp ᴄᴄ|ᴍᴍ|ʏʏ|ᴄᴠᴠ
Status: [$ppstatus $pptick]
Comment: $ppcomment
-------------------------------------------------
[𖠧]Gateway Levi (3$) 
[Stripe]
↳𝙵𝚘𝚛𝚖𝚊𝚝𝚘:/le ᴄᴄ|ᴍᴍ|ʏʏ|ᴄᴠᴠ
Status: [$lestatus $letick]
Comment: $lecomment
";

/* It's a variable that contains a string. */
$herramientas = "<b>
[🏔]  𝙏𝙤𝙤𝙡𝙨 𝙇𝙞𝙨𝙩 [🏔] 

------------------------------------------
[🏝] 𝗖𝗢𝗠𝗔𝗡𝗗𝗢: /gen
𝗙𝗼𝗿𝗺𝗮𝘁: 𝗰𝗰 | 𝗺| 𝘆 | 𝗰𝘃𝘃 
𝐒𝐭𝐚𝐭𝐮𝐬: ✅

[🏝]𝗖𝗢𝗠𝗔𝗡𝗗𝗢: /bin
𝗙𝗼𝗿𝗺𝗮𝘁: 𝗰𝗰 | 𝗺| 𝘆 | 𝗰𝘃𝘃 
𝐒𝐭𝐚𝐭𝐮𝐬: ✅

[🏝]𝗖𝗢𝗠𝗔𝗡𝗗𝗢: /rand
𝗙𝗼𝗿𝗺𝗮𝘁: US, CA, AU, ES, ETC
𝐒𝐭𝐚𝐭𝐮𝐬: ✅

[🏝]𝗖𝗢𝗠𝗔𝗡𝗗𝗢: /git
𝗙𝗼𝗿𝗺𝗮𝘁: git + name
𝐒𝐭𝐚𝐭𝐮𝐬: ✅

[🏝]𝗖𝗢𝗠𝗔𝗡𝗗𝗢: /ip
𝗙𝗼𝗿𝗺𝗮𝘁: ip Lookup
𝐒𝐭𝐚𝐭𝐮𝐬: ✅
</b>";
