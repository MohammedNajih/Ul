<?php
if(strpos($text,'$unauth') ===0){
    if($user_id == "1395727975" or $user_id == "5435018617" or $user_id == "5435534816" or $user_id == "5670832481" or $user_id == "5166848362"){}
else{
    exit();
}
    $auth = explode(" ", $text)[1];
    $SQL = "SELECT * FROM `authorize` WHERE chats=".$auth;
    $CONSULTA = mysqli_query(mysqlcon(),$SQL);
    $f = mysqli_num_rows($CONSULTA);
        $SQL = "DELETE FROM authorize WHERE `authorize`.`chats` = '$auth'";
        $cs = mysqli_query(mysqlcon(),$SQL);
        $content = ['chat_id' => $chat_id, 'text' => "<b>⚠️ Chat Demote successfully</b>", 'reply_to_message_id' => $msg_id, 'parse_mode' => 'html'];
        $m1  = SendMessage($content);
    
}